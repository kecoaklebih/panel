const fs = require('fs')

global.packname = 'erlaz'
global.owner = "6287745262652@s.whatsapp.net"
global.author = '0557'
global.namaowner = "ERLAZ OFFICIAL"
global.namabot = "X-TRAVAS"
global.linkch = 'https://whatsapp.com/channel/0029Vb5H9jX7j6gCCKrqvb3A'
global.idch = "120363417091214256@newsletter"

global.status = true
global.welcome = true
global.antispam = true
global.autoread = false

global.mess = {
    group: "ngapain? pfft khusus grup sayang",
    admin: "ngapain? pfft khusus admin sayang",
    owner: "ngapain? lu bukan owner",
    premium: "khusus user premium",
    botadmin: "bot bukan admin",
    private: "khusus private chat"
}

let file = require.resolve(__filename)
require('fs').watchFile(file, () => {
  require('fs').unwatchFile(file)
  console.log('\x1b[0;32m'+__filename+' \x1b[1;32mupdated!\x1b[0m')
  delete require.cache[file]
  require(file)
})
